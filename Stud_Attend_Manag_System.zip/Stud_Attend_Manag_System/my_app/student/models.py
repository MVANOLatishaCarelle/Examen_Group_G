from django.db import models

# Create your models here.
from django.contrib.auth.models import User
from django.utils import timezone

class Staff(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=20)
    surname = models.CharField(max_length=20)

    def __str__(self):
        return self.user.username

class Bac(models.Model):
    name_class = models.CharField(max_length=20)
    faculty = models.CharField(max_length=20)

    def __str__(self):
        return self.name_class

class Course(models.Model):
    bac = models.ForeignKey(Bac, on_delete=models.CASCADE)
    name_course = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.bac} - {self.name_course}"

class Student(models.Model):
    # bac = models.ForeignKey(Bac, on_delete=models.CASCADE)
    student_id = models.CharField(max_length=20)

    def __str__(self):
        return F"{self.bac} - {self.student_id}"
    
    # Méthode pour calculer le pourcentage de présence
    def attendance_percentage(self):
        total_classes = Attendance.objects.filter(student=self).count()
        if total_classes == 0:
            return 0  # Pour éviter la division par zéro
        attended_classes = Attendance.objects.filter(student=self, status='Present').count()
        return (attended_classes / total_classes) * 100

    # Méthode pour vérifier l'éligibilité
    def is_eligible(self):
        return self.attendance_percentage() >= 75

class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(default=timezone.now)
    status = models.CharField(max_length=10, choices=[
        ('Present', 'Present'),
        ('Absent', 'Absent'),
        ('Late', 'Late')
    ])

    def __str__(self):
        return f"{self.student} - {self.date} - {self.status}"



