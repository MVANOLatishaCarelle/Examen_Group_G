from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'), #
    path('', views.user_login, name='login'), #
    path('mark_attendance/', views.mark_attendance, name='mark_attendance'), #
    path('attendance_report/', views.attendance_report, name='attendance_report'), #
    path('student_report/', views.student_attendance_report, name='student_report'), # <int:student_id>
    path('class_report/', views.class_attendance_report, name='class_report'), # 
    path('search/', views.search_students, name='search_students'), # 
]
