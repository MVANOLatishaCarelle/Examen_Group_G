from django.contrib import admin

# Register your models here.
from .models import Student, Attendance  # Importer les modèles

# Enregistrer les modèles dans l'admin
admin.site.register(Student)
admin.site.register(Attendance)